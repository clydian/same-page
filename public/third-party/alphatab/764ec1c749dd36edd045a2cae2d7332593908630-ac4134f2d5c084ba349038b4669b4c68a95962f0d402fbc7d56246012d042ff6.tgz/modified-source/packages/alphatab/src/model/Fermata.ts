/**
 * Lists all types of fermatas
 * @public
 */
export enum FermataType {
    /**
     * A short fermata (triangle symbol)
     */
    Short = 0,
    /**
     * A medium fermata (round symbol)
     */
    Medium = 1,
    /**
     * A long fermata (rectangular symbol)
     */
    Long = 2
}

/**
 * Represents a fermata.
 * @cloneable
 * @json
 * @json_strict
 * @public
 */
export class Fermata {
    /**
     * Gets or sets the type of fermata.
     */
    public type: FermataType = FermataType.Short;

    /** Whether the source fermata is inverted and belongs below its staff. */
    public isInverted: boolean = false;

    /**
     * Gets or sets the actual length of the fermata.
     */
    public length: number = 0;
}
