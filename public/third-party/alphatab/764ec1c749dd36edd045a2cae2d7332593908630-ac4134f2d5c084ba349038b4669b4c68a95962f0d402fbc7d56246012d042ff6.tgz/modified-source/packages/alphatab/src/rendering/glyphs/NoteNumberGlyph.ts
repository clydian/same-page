import { BendType } from '@coderline/alphatab/model/BendType';
import type { Font } from '@coderline/alphatab/model/Font';
import { HarmonicType } from '@coderline/alphatab/model/HarmonicType';
import { ModelUtils } from '@coderline/alphatab/model/ModelUtils';
import { type Note, NoteSubElement } from '@coderline/alphatab/model/Note';
import { NotationElement, NotationMode } from '@coderline/alphatab/NotationSettings';
import type { ICanvas } from '@coderline/alphatab/platform/ICanvas';
import { Glyph } from '@coderline/alphatab/rendering/glyphs/Glyph';
import type { TabBarRenderer } from '@coderline/alphatab/rendering/TabBarRenderer';
import type { BeatBounds } from '@coderline/alphatab/rendering/utils/BeatBounds';
import { Bounds } from '@coderline/alphatab/rendering/utils/Bounds';
import { ElementStyleHelper } from '@coderline/alphatab/rendering/utils/ElementStyleHelper';
import { NoteBounds } from '@coderline/alphatab/rendering/utils/NoteBounds';

/**
 * @internal
 */
export class NoteNumberGlyph extends Glyph {
    private _note: Note;
    private _noteString: string | null = null;
    private _trillNoteString: string | null = null;
    private _trillNoteStringWidth: number = 0;

    public isEmpty: boolean = false;
    public noteStringWidth: number = 0;

    public constructor(x: number, y: number, note: Note) {
        super(x, y);
        this._note = note;
    }

    private get _padding() {
        return (this.renderer as TabBarRenderer).lineSpacing * 0.25;
    }

    public override getBoundingBoxTop(): number {
        return this.y - this.height / 2 - this._padding;
    }

    public override getBoundingBoxBottom(): number {
        return this.y + this.height / 2;
    }

    public override doLayout(): void {
        const n: Note = this._note;
        let fret: number = n.fret - n.beat.voice.bar.staff.transpositionPitch;
        if (n.harmonicType === HarmonicType.Natural && n.harmonicValue !== 0) {
            fret = n.harmonicValue - n.beat.voice.bar.staff.transpositionPitch;
        }
        if (!n.isTieDestination) {
            this._noteString = n.isDead ? 'x' : fret.toString();
            if (n.isGhost || n.isNoteHeadParenthesized) {
                this._noteString = `(${this._noteString})`;
            } else if (n.harmonicType === HarmonicType.Natural) {
                // only first decimal char
                const i: number = this._noteString.indexOf(String.fromCharCode(46));
                if (i >= 0) {
                    this._noteString = this._noteString.substr(0, i + 2);
                }
                this._noteString = `<${this._noteString}>`;
            }
        } else if (
            (n.beat.index === 0 && this.renderer.settings.notation.notationMode === NotationMode.GuitarPro) ||
            ((n.bendType === BendType.Bend || n.bendType === BendType.BendRelease) &&
                this.renderer.settings.notation.isNotationElementVisible(NotationElement.TabNotesOnTiedBends))
        ) {
            this._noteString = `(${(n.tieOrigin!.fret - n.beat.voice.bar.staff.transpositionPitch).toString()})`;
        } else {
            this._noteString = '';
        }
        if (n.isTrill) {
            this._trillNoteString = `(${(n.trillFret - n.beat.voice.bar.staff.transpositionPitch).toString()})`;
        } else if (!ModelUtils.isAlmostEqualTo(n.harmonicValue, 0)) {
            switch (n.harmonicType) {
                case HarmonicType.Artificial:
                case HarmonicType.Pinch:
                case HarmonicType.Tap:
                case HarmonicType.Semi:
                case HarmonicType.Feedback:
                    let s: string = (fret + n.harmonicValue).toString();
                    // only first decimal char
                    const i: number = s.indexOf(String.fromCharCode(46));
                    if (i >= 0) {
                        s = s.substr(0, i + 2);
                    }
                    this._trillNoteString = `<${s}>`;
                    break;
                default:
                    this._trillNoteString = '';
                    break;
            }
        } else {
            this._trillNoteString = '';
        }
        this.isEmpty = !this._noteString;
        if (!this.isEmpty) {
            this.renderer.scoreRenderer.canvas!.font = this.renderer.resources.tablatureFont;
            const hasTrill: boolean = !!this._trillNoteString;
            this.noteStringWidth = this.renderer.scoreRenderer.canvas!.measureText(
                this._noteString + (hasTrill ? ' ' : '')
            ).width;
            this.width = this.noteStringWidth;
            this.height = this.renderer.scoreRenderer.canvas!.font.size;
            if (hasTrill) {
                this.renderer.scoreRenderer.canvas!.font = this.renderer.resources.graceFont;
                this._trillNoteStringWidth =
                    3 + this.renderer.scoreRenderer.canvas!.measureText(this._trillNoteString).width;
                this.width += this._trillNoteStringWidth;
            }
        }
    }

    public override paint(cx: number, cy: number, canvas: ICanvas): void {
        if (this.isEmpty) {
            return;
        }
        const textWidth: number = this.noteStringWidth + this._trillNoteStringWidth;
        const x: number = cx + this.x + (this.width - textWidth) / 2;
        const y = cy + this.y;

        this.paintTrill(x, y, canvas);

        using _ = ElementStyleHelper.note(canvas, NoteSubElement.GuitarTabFretNumber, this._note);
        canvas.fillText(this._noteString!, x, y);

        // canvas.color = Color.random();
        // canvas.fillRect(cx + this.x, cy + this.y - this.height / 2, this.width, this.height);
    }
    paintTrill(x: number, cy: number, canvas: ICanvas) {
        using _ = ElementStyleHelper.note(canvas, NoteSubElement.GuitarTabFretNumber, this._note);
        const prevFont: Font = this.renderer.scoreRenderer.canvas!.font;
        this.renderer.scoreRenderer.canvas!.font = this.renderer.resources.graceFont;
        canvas.fillText(this._trillNoteString!, x + this.noteStringWidth, cy);
        this.renderer.scoreRenderer.canvas!.font = prevFont;
    }

    public buildBoundingsLookup(beatBounds: BeatBounds, cx: number, cy: number) {
        const noteBounds: NoteBounds = new NoteBounds();
        noteBounds.note = this._note;
        noteBounds.noteHeadBounds = new Bounds();
        noteBounds.noteHeadBounds.x = cx + this.x;
        noteBounds.noteHeadBounds.y = cy + this.y - this.height / 2;
        noteBounds.noteHeadBounds.w = this.width;
        noteBounds.noteHeadBounds.h = this.height;
        beatBounds.addNote(noteBounds);
    }
}
