# Same Page alphaTab source changes

This is a modified alphaTab build, not an upstream release. alphaTab remains MPL-2.0; original notices and complete modified files are included.

Public upstream: https://github.com/CoderLine/alphaTab.git
Upstream commit: 022a45c8e42370f9e12e68949d11eada370da83d
Source commit identifier: 72e2fdee21e71190f75131f5de68b64acfd9779c
Source tree: 9aeb16963985c8826a9f034222bcecab1e76c075

To rebuild, clone the public upstream, check out the upstream commit, apply changes.patch, and verify modified-source against SOURCE-MANIFEST.json. Use an independent clone with a real .git directory. With Node 24 run npm ci --ignore-scripts, npm run build, npm run build-vite and npm run build-webpack. The package preparation step is the upstream packages/alphatab/scripts/prepack.mts. Builds preserve upstream license banners.

The source tree and file hashes identify the code. Build timestamps and local Git metadata can change output bytes; this does not assert bit-for-bit reproducible bundles. The distributable package checksum must be verified separately.
