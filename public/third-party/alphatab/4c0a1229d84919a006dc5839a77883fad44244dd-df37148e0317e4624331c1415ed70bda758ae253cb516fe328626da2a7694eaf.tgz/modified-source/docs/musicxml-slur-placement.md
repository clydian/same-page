# MusicXML phrase-slur placement

`Note.slurPlacement` and public `SlurPlacement` retain the notation side of an outgoing phrase slur. `Automatic` (0) preserves the existing stem-based layout; `Above` (1) and `Below` (2) request the corresponding side. Note cloning and Worker JSON retain this field. Older JSON without the field keeps `Automatic`.

The MusicXML importer reads explicit `<slur placement="above|below">` on the start element. When the start omits placement, an explicit matching stop supplies the side. An explicit start remains authoritative when endpoint attributes disagree. The existing Note model still supports only one outgoing origin-to-destination phrase link. Two numbered outgoing slurs from a shared note head are not represented independently; SamePage issue #498 tracks this pre-existing limitation, with unchanged red controls on production and this fix. Do not duplicate source notes or change source sides to hide that limitation. This is one side for the existing origin-to-destination phrase model, including its continuation on later systems; it does not model an S-shaped slur with conflicting endpoint sides.

The override belongs only to `ScoreSlurGlyph`. Pitch ties, note duration, MIDI generation, automatic unspecified slurs and effect-slur construction are unchanged. No source XML rewrite is required. Above/below placement differs from MusicXML `orientation` (overhand/underhand); custom orientation, continuation-specific shape and Bezier control-point overrides remain outside this change. Generic collision avoidance between an above phrase slur and another above notation is not provided by this side-retention fix.

Regression tests: `test/rendering/MusicXmlSlurPlacement.test.ts` covers import, real native SVG geometry, public JSON, note clone, legacy JSON, Page/Horizontal, cross-system continuation, simultaneous voices, start/stop precedence and tie isolation. The original installed-package red repro and actual prepare/render Worker browser captures accompany SamePage issue #497.

Reference: https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/slur/
