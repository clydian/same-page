# Same Page alphaTab source changes

This is a modified alphaTab build, not an upstream release. alphaTab remains MPL-2.0; original notices and complete modified files are included.

Public upstream: https://github.com/CoderLine/alphaTab.git
Upstream commit: 022a45c8e42370f9e12e68949d11eada370da83d
Source commit identifier: cc0b4a00fe0033f4cd04f86a4a8f69eaf1d32210
Source tree: df2636a037dfa3b2462b67fc1b5cc9eebcf3b8bb

To rebuild, clone the public upstream, check out the upstream commit, apply changes.patch, and verify modified-source against SOURCE-MANIFEST.json. Use an independent clone with a real .git directory. With Node 24 run npm ci --ignore-scripts, npm run build, npm run build-vite and npm run build-webpack. The package preparation step is the upstream packages/alphatab/scripts/prepack.mts. Builds preserve upstream license banners.

The source tree and file hashes identify the code. Build timestamps and local Git metadata can change output bytes; this does not assert bit-for-bit reproducible bundles. The distributable package checksum must be verified separately.
