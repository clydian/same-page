# Modified alphaTab for Same Page

Version: 1.8.4-samepage.17
Source commit: 9bcd697196c3f55ee21eeadb2b823e9b138482bb
Source archive: alphatab-source-9bcd697196c3f55ee21eeadb2b823e9b138482bb.tgz
Source archive SHA-256: e0e405e96f9f425f4278f22dce9ab1ac12676a167b9aa71f5168b9929a278a1e

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
