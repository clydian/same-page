# Modified alphaTab for Same Page

Version: 1.8.4-samepage.4
Source commit: 0bf4e52d89140dbfbcfdc2cceb0a37bc8d234214
Source archive: alphatab-source-0bf4e52d89140dbfbcfdc2cceb0a37bc8d234214.tgz
Source archive SHA-256: 62ca8557d669a78d7dc3ffa28527ff5b8a02ca0d175b4e5603bc2b31bf969dc4

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
