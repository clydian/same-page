# Modified alphaTab for Same Page

Version: 1.8.4-samepage.10
Source commit: 65c37242b8833a66f1bc5a752e99b5550dd29061
Source archive: alphatab-source-65c37242b8833a66f1bc5a752e99b5550dd29061.tgz
Source archive SHA-256: cbd8fcc2da7099008e30442f609503ea630627e00625050545887530863fb0d5

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
