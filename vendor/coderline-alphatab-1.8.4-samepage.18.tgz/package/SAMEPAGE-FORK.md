# Modified alphaTab for Same Page

Version: 1.8.4-samepage.18
Source commit: aa5e25f3d29eeab8dea85328eb38805b8b70bfef
Source archive: alphatab-source-aa5e25f3d29eeab8dea85328eb38805b8b70bfef.tgz
Source archive SHA-256: 8ab3ad30caa5b70d528ab5418a9dc17b743abd16ff4b761ee8c1b5fb133661b2

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
