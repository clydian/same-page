# Modified alphaTab for Same Page

Version: 1.8.4-samepage.2
Source commit: d917b3e3faa5f64e1c524f9a41af19b537bf3a49
Source archive: alphatab-source-d917b3e3faa5f64e1c524f9a41af19b537bf3a49.tgz
Source archive SHA-256: 283d6784a7601396fde378f22b2ad595c6df647a045563dc10d910d508211648

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
