# Modified alphaTab for Same Page

Version: 1.8.4-samepage.1
Source commit: 9c1e050e3b02673c9d5344ca1b6fa03a476f0f18
Source archive: alphatab-source-9c1e050e3b02673c9d5344ca1b6fa03a476f0f18.tgz
Source archive SHA-256: bab1a570b21b5a19d12a14fef20757736eadb291f25232a7e68ba5de40db5191

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
