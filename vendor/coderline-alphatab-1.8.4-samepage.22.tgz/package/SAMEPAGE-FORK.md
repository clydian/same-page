# Modified alphaTab for Same Page

Version: 1.8.4-samepage.22
Source commit: a320a5478087ba88f4940ac2faaaf2eb4d0638a3
Source archive: alphatab-source-a320a5478087ba88f4940ac2faaaf2eb4d0638a3.tgz
Source archive SHA-256: 6c157617a641052e216304e78adcba78a6b3fdbc1419cb8038f71fff64051b41

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
