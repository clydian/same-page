# Modified alphaTab for Same Page

Version: 1.8.4-samepage.6
Source commit: d0fb909fd80d180761a4a7e22dccc87c735424c5
Source archive: alphatab-source-d0fb909fd80d180761a4a7e22dccc87c735424c5.tgz
Source archive SHA-256: 02242a5571fe4860b1edfc98343d964284774c11a334a5954a4a1c24e50e397d

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
