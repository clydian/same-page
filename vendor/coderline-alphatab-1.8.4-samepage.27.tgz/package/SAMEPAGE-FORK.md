# Modified alphaTab for Same Page

Version: 1.8.4-samepage.27
Source commit: a0cbdbe7686b4c8ac555bce29c8eebd585b80b5c
Source archive: alphatab-source-a0cbdbe7686b4c8ac555bce29c8eebd585b80b5c.tgz
Source archive SHA-256: 972a7ad77fc9e11f72386c1f9903951b76325414e201ae581fd8165dbb882d1f

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
