# Modified alphaTab for Same Page

Version: 1.8.4-samepage.12
Source commit: 62ca99c370271b74b0454bcbf02ea0341d2cfb43
Source archive: alphatab-source-62ca99c370271b74b0454bcbf02ea0341d2cfb43.tgz
Source archive SHA-256: 5bcdc416f3987b1a9c6e19a289fa70b9d78de3c368daffb55c8feeea0ea7c633

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
