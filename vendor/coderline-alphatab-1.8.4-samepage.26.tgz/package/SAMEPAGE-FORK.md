# Modified alphaTab for Same Page

Version: 1.8.4-samepage.26
Source commit: c86fb87b8c0c6e1ac01983553e5ad7cf54fcfca8
Source archive: alphatab-source-c86fb87b8c0c6e1ac01983553e5ad7cf54fcfca8.tgz
Source archive SHA-256: ea276475050e00ecbd841df393a8ac7ba764cbfae339687a96d5ff06b8dc6f3a

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
