# Modified alphaTab for Same Page

Version: 1.8.4-samepage.7
Source commit: afe9089e99ed6044a1dc0030c14a149be44ddcd6
Source archive: alphatab-source-afe9089e99ed6044a1dc0030c14a149be44ddcd6.tgz
Source archive SHA-256: 04ea2cd0c31306f3263daa5570d6abe1762110d7714e53972428df15f7b00154

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
