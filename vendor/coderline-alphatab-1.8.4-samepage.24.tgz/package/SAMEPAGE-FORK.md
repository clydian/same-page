# Modified alphaTab for Same Page

Version: 1.8.4-samepage.24
Source commit: 25440aca858f0451ec17e30e082b534282552409
Source archive: alphatab-source-25440aca858f0451ec17e30e082b534282552409.tgz
Source archive SHA-256: e598b6f9223a3d7da6ef93fc5792fedaa1c14012782caada3072d1c1246a26c0

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
