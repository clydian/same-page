# Modified alphaTab for Same Page

Version: 1.8.4-samepage.25
Source commit: 1798e10c861a5cd50d315377b4a5221996b71d11
Source archive: alphatab-source-1798e10c861a5cd50d315377b4a5221996b71d11.tgz
Source archive SHA-256: 61d6d26321b99ee5bc16b0f9ed501b376bae0de6ae1ad9a735938f076504205b

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
