# Modified alphaTab for Same Page

Version: 1.8.4-samepage.16
Source commit: 764ec1c749dd36edd045a2cae2d7332593908630
Source archive: alphatab-source-764ec1c749dd36edd045a2cae2d7332593908630.tgz
Source archive SHA-256: ac4134f2d5c084ba349038b4669b4c68a95962f0d402fbc7d56246012d042ff6

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
