# Modified alphaTab for Same Page

Version: 1.8.4-samepage.23
Source commit: 72e2fdee21e71190f75131f5de68b64acfd9779c
Source archive: alphatab-source-72e2fdee21e71190f75131f5de68b64acfd9779c.tgz
Source archive SHA-256: ce034219e6bb1842b178c22769fb2ac92fbddc5e15f9cd32a95e7fb86b75fce8

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
