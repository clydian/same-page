# Modified alphaTab for Same Page

Version: 1.8.4-samepage.19
Source commit: aa953f92779edae2674431db65c696c3568ff973
Source archive: alphatab-source-aa953f92779edae2674431db65c696c3568ff973.tgz
Source archive SHA-256: 1a4cdd004d2489be8bb89ee837c54e1cea4be088bf651344fca20758486bb8d0

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
