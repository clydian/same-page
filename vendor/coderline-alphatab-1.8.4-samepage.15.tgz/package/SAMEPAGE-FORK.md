# Modified alphaTab for Same Page

Version: 1.8.4-samepage.15
Source commit: 80abe1dd2e4497718b57fa6987f0f01f60e3b80f
Source archive: alphatab-source-80abe1dd2e4497718b57fa6987f0f01f60e3b80f.tgz
Source archive SHA-256: b3afe7ba52a058bccf12b06ef0a88916142bf61f2665653f17c1cb2a6ac910c2

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
