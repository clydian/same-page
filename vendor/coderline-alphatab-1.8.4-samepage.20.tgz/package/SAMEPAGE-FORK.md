# Modified alphaTab for Same Page

Version: 1.8.4-samepage.20
Source commit: cc0b4a00fe0033f4cd04f86a4a8f69eaf1d32210
Source archive: alphatab-source-cc0b4a00fe0033f4cd04f86a4a8f69eaf1d32210.tgz
Source archive SHA-256: 60b59f26c4c494aae5178f67b2258b36949dace948253e24cb91daec4c297ec2

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
