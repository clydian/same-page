# Modified alphaTab for Same Page

Version: 1.8.4-samepage.8
Source commit: bdd07a6b2a0e17f99dcd44697867f605549f900a
Source archive: alphatab-source-bdd07a6b2a0e17f99dcd44697867f605549f900a.tgz
Source archive SHA-256: 1e910fabd5836c04a1f4aee9efda039efdb8b9433bad643e63a359cba84c2140

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
