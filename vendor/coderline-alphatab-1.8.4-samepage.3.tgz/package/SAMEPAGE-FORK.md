# Modified alphaTab for Same Page

Version: 1.8.4-samepage.3
Source commit: a67e8a34112faeaccf1fc2b019cf7b580ada73de
Source archive: alphatab-source-a67e8a34112faeaccf1fc2b019cf7b580ada73de.tgz
Source archive SHA-256: bd177deaf51464d0483a55202409920c5ce89709d447e32098c5efba23e1912d

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
