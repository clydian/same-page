# Modified alphaTab for Same Page

Version: 1.8.4-samepage.14
Source commit: a242e8f100026905bf4b53eec420b2b445cea843
Source archive: alphatab-source-a242e8f100026905bf4b53eec420b2b445cea843.tgz
Source archive SHA-256: 4a7568081b17dec92993b64139423f4968217256bf02230c64593ecf0e6ce1f8

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
