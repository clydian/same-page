# Modified alphaTab for Same Page

Version: 1.8.4-samepage.14
Source commit: c91004f04ec585fd588bdffc71f5c6d4f0dd02e9
Source archive: alphatab-source-c91004f04ec585fd588bdffc71f5c6d4f0dd02e9.tgz
Source archive SHA-256: 8e16328e7b51de6d9973d3c4a519cdfed96fec0e59b74dbf0fd607154a8fb68d

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
