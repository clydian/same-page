# Chorus Player

Private, versioned source package shared by Chorus and Same Page. `./format` has no browser/audio dependency and performs bounded XML/MXL admission. `./engine` preserves the existing MusicXML timing and dynamics corrections. The main export provides an owned playback session.

Hosts supply bytes and a container, own authentication/navigation and dispose the session on scope changes. No private scores, room configuration or credentials are included. Install alphaTab's matching Vite plugin in browser hosts to copy fonts/soundfonts and bundle workers; configure lazy loading and PWA exclusions in the host.

Produce a reproducible release artifact with `npm pack --workspace @clydian/chorus-player`. The consuming application pins that artifact/version and verifies its integrity through its lockfile. Never use an adjacent checkout or a floating runtime CDN URL in production.


The engine collects simple numeric MusicXML metronomes and `sound/@tempo` before
import. Beat units and dots become quarter-note BPM; offsets are converted from
the current divisions at the direction cursor, including backup/forward voices.
Explicit sound tempo wins at the same onset, and sound-only automation stays
hidden. Preparation carries this timeline to the engine without rewriting the
original metronome notation. Older prepared payloads use a byte-parser fallback.
Metric modulations, tied units, tempo ranges, pass-specific `sound/@time-only`
and negative out-of-measure onsets
leave that measure's native automation unchanged and require source review.

alphaTab's native metronome glyph uses a quarter note and equivalent BPM. The
source XML retains its original half/dotted beat mark for export and source
inspection; this correction does not provide exact beat-unit glyph rendering.
Validate the actual MIDI tempo timeline, not merely the XML or UI tempo label.
Run `node --experimental-strip-types --test tests/musicxml-metronome.test.mjs`
for the focused regressions, then `npm test` and `npm run build`.
