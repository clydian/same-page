# Modified alphaTab for Same Page

Version: 1.8.4-samepage.9
Source commit: a7f67663591fc6cea104b44e1f331d27143089da
Source archive: alphatab-source-a7f67663591fc6cea104b44e1f331d27143089da.tgz
Source archive SHA-256: 96b3ba0c2e9cd777d2f389eb7021704a4dd4e3ae9b08c23c9a025d057026c3a0

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
