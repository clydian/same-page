# Modified alphaTab for Same Page

Version: 1.8.4-samepage.5
Source commit: 6fb2eac48b8d98518c12f220e4a851b7b4594fed
Source archive: alphatab-source-6fb2eac48b8d98518c12f220e4a851b7b4594fed.tgz
Source archive SHA-256: 68a48e0c10c5e932d671b95562d393e38ba6533e7f858902d3e7c76b21eb68c9

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
