# Modified alphaTab for Same Page

Version: 1.8.4-samepage.13
Source commit: f931703ac15d583c50f6883288332daa7d71ffe2
Source archive: alphatab-source-f931703ac15d583c50f6883288332daa7d71ffe2.tgz
Source archive SHA-256: 284a57fe9cf040b8e8700be023a53c6231d4f84fb6d408cf296dc2a0f0b29c3c

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
