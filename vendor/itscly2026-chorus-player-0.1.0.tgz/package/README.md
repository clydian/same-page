# Chorus Player

Private, versioned source package shared by Chorus and Same Page. `./format` has no browser/audio dependency and performs bounded XML/MXL admission. `./engine` preserves the existing MusicXML timing and dynamics corrections. The main export provides an owned playback session.

Hosts supply bytes and a container, own authentication/navigation and dispose the session on scope changes. No private scores, room configuration or credentials are included. Install alphaTab's matching Vite plugin in browser hosts to copy fonts/soundfonts and bundle workers; configure lazy loading and PWA exclusions in the host.

Produce a reproducible release artifact with `npm pack --workspace @itscly2026/chorus-player`. The consuming application pins that artifact/version and verifies its integrity through its lockfile. Never use an adjacent checkout or a floating runtime CDN URL in production.
