# Modified alphaTab for Same Page

Version: 1.8.4-samepage.11
Source commit: 4c0a1229d84919a006dc5839a77883fad44244dd
Source archive: alphatab-source-4c0a1229d84919a006dc5839a77883fad44244dd.tgz
Source archive SHA-256: df37148e0317e4624331c1415ed70bda758ae253cb516fe328626da2a7694eaf

Original authorship and MPL-2.0 notices are retained. This package is not published to the upstream npm scope. Consumers install this local artifact as the shared native renderer; the player requires its exact version as a peer. Hosts must also make the enclosed source archive available at a stable, versioned public URL and retain its license notices when distributing the runtime.
